package com.tweetapp.entity;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class Environmen {

	@Value("${server.port}")
	public Integer service_port;
	@Value("${logging.level.root}")
	public String log_level;

	public Integer getService_port() {
		return service_port;
	}

	public void setService_port(Integer service_port) {
		this.service_port = service_port;
	}

	public String getLog_level() {
		return log_level;
	}

	public void setLog_level(String log_level) {
		this.log_level = log_level;
	}

}
