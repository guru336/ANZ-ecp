package com.tweetapp.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Base {

	private String service_name = "myapplication";
	private String version = "1.0.0";
	private String git_commit_sha = "abc57858585";
	@Autowired
	private Environmen environment;

	public String getService_name() {
		return service_name;
	}

	public void setService_name(String service_name) {
		this.service_name = service_name;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getGit_commit_sha() {
		return git_commit_sha;
	}

	public void setGit_commit_sha(String git_commit_sha) {
		this.git_commit_sha = git_commit_sha;
	}

	public Environmen getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environmen environment) {
		this.environment = environment;
	}

}
