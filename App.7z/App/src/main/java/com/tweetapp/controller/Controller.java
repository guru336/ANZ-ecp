package com.tweetapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.entity.Base;

@RestController
public class Controller {
	
	@Autowired
	Base b;
	
	@GetMapping("/info")
	public ResponseEntity<?> getInfo(){
			
		return new ResponseEntity<>(b,HttpStatus.OK);
		
	}

}
